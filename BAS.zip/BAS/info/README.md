# /info folder
Folder containing .txt files about the informations of the blockchain stored.
